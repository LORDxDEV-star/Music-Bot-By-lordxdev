
module.exports = {
  token: process.env.TOKEN,
  prefix: '!',
  clientId: process.env.CLIENT_ID
};
