
const { Client, GatewayIntentBits } = require('discord.js');
const { MusicClient } = require('./structures/MusicClient');
const config = require('./config');

const client = new MusicClient({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

client.start();
