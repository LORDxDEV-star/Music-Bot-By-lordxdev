
module.exports = {
  name: 'help',
  description: 'Show all available commands',
  execute: async (message) => {
    const commands = [
      '!play - Play a song',
      '!queue - Show current queue',
      '!skip - Skip current song',
      '!stop - Stop playback',
      '!pause - Pause playback',
      '!resume - Resume playback',
      '!volume - Adjust volume',
      '!nowplaying - Show current song',
      '!shuffle - Shuffle queue',
      '!loop - Toggle loop mode'
    ];
    message.reply(commands.join('\n'));
  }
};
