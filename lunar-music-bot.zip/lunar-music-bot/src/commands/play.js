
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  name: 'play',
  description: 'Play a song from YouTube',
  execute: async (message, args) => {
    // Play command logic will be implemented here
    message.reply('Play command - Implementation pending');
  }
};
