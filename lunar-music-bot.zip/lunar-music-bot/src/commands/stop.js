
module.exports = {
  name: 'stop',
  description: 'Stop the music playback',
  execute: async (message) => {
    // Stop command logic will be implemented here
    message.reply('Stop command - Implementation pending');
  }
};
