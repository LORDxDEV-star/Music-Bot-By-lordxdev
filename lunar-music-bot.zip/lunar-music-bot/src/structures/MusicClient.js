
const { Client, Collection } = require('discord.js');
const fs = require('fs');
const path = require('path');

class MusicClient extends Client {
  constructor(options) {
    super(options);
    this.commands = new Collection();
    this.loadCommands();
    this.loadEvents();
  }

  loadCommands() {
    const commandFiles = fs.readdirSync(path.join(__dirname, '../commands'))
      .filter(file => file.endsWith('.js'));
    
    for (const file of commandFiles) {
      const command = require(`../commands/${file}`);
      this.commands.set(command.name, command);
    }
  }

  loadEvents() {
    const eventFiles = fs.readdirSync(path.join(__dirname, '../events'))
      .filter(file => file.endsWith('.js'));
    
    for (const file of eventFiles) {
      const event = require(`../events/${file}`);
      this.on(event.name, (...args) => event.execute(...args));
    }
  }

  start() {
    this.login(process.env.TOKEN);
  }
}

module.exports = { MusicClient };
