
# Lunar Music Bot

A Discord music bot with various features including play, queue, skip, and more.

## Setup
1. Copy `.env.example` to `.env` and fill in your bot token
2. Install dependencies: `npm install`
3. Start the bot: `npm start`

## Commands
- !play - Play a song from YouTube
- !queue - Show current queue
- !skip - Skip current song
- !stop - Stop playback
- And more...
